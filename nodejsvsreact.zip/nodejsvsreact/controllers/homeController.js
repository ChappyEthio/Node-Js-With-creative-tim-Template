var conn = require('../model/dbconnection');
const Joi = require("joi");

const titleholder = '';

const indexView = (req, res, next) => {
  
    res.render('home', { titleholder: home });

}
const service = (req, res, next) => {
   
    const headertitle = "Service";
    // conn.insertdata()

    res.render('contact', { titleholder: headertitle, message: req.flash('message') });
}

const savecategory = (req, res, next) => {
    res.header("Access-Control-Allow-Origin", "http://localhost:3000");

    const headertitle = "Service";

    const data = conn.insertdata(req.body.category);
    console.log(data);

    //if(data === true){

    req.flash("message", "Category Successfuly Saved");
    res.redirect('/service');

    //}

}

const postjob = async (req, res, next) => {
    const headertitle = "Post Job";

    result =await conn.GetCategory().then(results =>

        res.render('postjob', { titleholder: headertitle, results: results })
    );




}

const createpost = (req, res, next) => {

    const { jobcategory, joblocation, jobtitile, startdate, enddate, jobdescription, jobrequirment, jobapply, joblevel, joblogo, jobsalary } = req.body;


    console.log(joblocation);


}

const companyprofile = (req, res, next) => {
    const headertitle = "Company Profile";

    res.render('companyprofile', { titleholder: headertitle })
}


module.exports = {
    indexView, service, postjob, companyprofile, savecategory,createpost
}