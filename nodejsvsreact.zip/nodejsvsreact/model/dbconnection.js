const mysql = require('mysql');

require('dotenv').config();

//console.log(process.env);

var connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  port:3306
});

connection.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }

  console.log('connected as id ' + connection.threadId);
  console.log('connected');
});

const insertdata = (tes) =>{


  
        var qstring=`jobcategoryname`;
        
        var qquery="INSERT INTO jobcategory ( "+ qstring+  " ) values ?";
            // func1
            //console.log(tes.length + " " + name.length);
              var query = connection.query(qquery,[[[tes]]] , function (error, results, fields) {
                if (error) throw error;

                // Neat!
              });

            //  res.send("Inserted");
             console.log('Inserted');
            //  console.log(query.sql);
          
       
return true;

}

const GetCategory =() =>{

  
  var qquery="SELECT * FROM jobportal.jobcategory";  

  return new Promise((resolve,reject)=>{

   
     connection.query(qquery , function (error, results, fields) {
      if (error) throw error;

      // Neat!
      resolve(results);
    });
  })
   
  
      
      


}


module.exports = {
    insertdata, GetCategory}
  
  
  //module.exports=insertdata;
  
  //module.export=connection;
  //module.exports=insertdata;
  