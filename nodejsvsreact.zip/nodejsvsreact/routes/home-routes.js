const express=require('express')
const {indexView,service, postjob,companyprofile,savecategory}=require('../controllers/homeController.js')

const router=express.Router();

router.get('/',indexView);
router.get('/service',service);
router.get('/postjob',postjob);
router.get('/companyprofile',companyprofile);
router.post('/savecategory',savecategory);


module.exports={
    routes:router
}
